#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
int main() {
  char *args[] = {"/bin/ls", "-lh", "/home", NULL};
 
  execv("/bin/ls", args);
 //it take arrgument in array form 
  return 0;
}


