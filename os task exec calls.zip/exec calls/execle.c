#include <unistd.h>
#include<stdio.h>
#include<stdlib.h>
int main() {
 // santax of execle(const char *path, const char *arg, ..., NULL, char * const envp[] );
  
  char *const env[] = {"HOSTNAME=www.fast.nu.edu.pk", "PORT=8080", NULL};
 
  execle("/bin/ls", "/bin/ls","-s", "-a", NULL, env);
 //env is the environment pointer array of user's choice whose  last element is NULL we have give path and commands in parameters
  return 0;
}

