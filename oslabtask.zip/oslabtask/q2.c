#include <iostream>
int main(){
  //they can't communicate one process cant be run in different programs run time different programs are not able communicate because they dont share anything common in them .they are completly unknown from each other.Every process can use heap memory to store and share data within the same  process but different processes are not allowed to share and store data
}
